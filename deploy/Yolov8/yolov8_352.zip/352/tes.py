# Open a new file in write mode (w)
with open('tes.txt', 'w') as file:
    # Write "success" to the file
    file.write("success")
    
    
print("udah boi")